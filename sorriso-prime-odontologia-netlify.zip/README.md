# Sorriso Prime Odontologia - Site Oficial

Site institucional moderno, responsivo e premium desenvolvido para a clínica fictícia **Sorriso Prime Odontologia**.

## 🚀 Como Executar Localmente

1. Instale as dependências:
```bash
npm install
```

2. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

3. Para gerar a versão de produção:
```bash
npm run build
```

## 🌐 Publicação no Netlify (Em menos de 1 minuto!)

### Opção 1: Arrastar e Soltar (Netlify Drop)
1. Execute `npm run build` na sua máquina para gerar a pasta `dist`.
2. Acesse [app.netlify.com/drop](https://app.netlify.com/drop).
3. Arraste a pasta `dist` gerada diretamente para a tela.
4. Seu site estará no ar instantaneamente com HTTPS gratuito!

### Opção 2: Conectar ao GitHub / GitLab
1. Suba o código para o seu repositório no GitHub.
2. No Netlify, clique em **Add new site** > **Import an existing project**.
3. Selecione o repositório. O arquivo `netlify.toml` já está configurado:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Clique em **Deploy Site**.

## 🎨 Paleta de Cores
- Branco (#FFFFFF)
- Azul-Claro (#0284C7 / #38BDF8 / #E0F2FE)
- Azul-Marinho / Slate (#0F172A / #1E293B / #0369A1)
